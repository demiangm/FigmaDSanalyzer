import * as data0 from './data/Biblioteca-Part.1.components.json';
import * as data1 from './data/Design-Tokens.styles.json';

export const dataFiles = [
  { fileName: 'Biblioteca-Part.1.components', data: data0 },
  { fileName: 'Design-Tokens.styles', data: data1 },
];